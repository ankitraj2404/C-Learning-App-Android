package com.example.flashcards_quiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
