import 'package:flashcards_quiz/common.dart';
import 'package:flashcards_quiz/create_acc.dart';
import 'package:flashcards_quiz/views/home_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  final TextEditingController userTextEditingController =
  TextEditingController();
  final TextEditingController passwordTextEditingController =
  TextEditingController();

  SharedPreferences? sharedPreferences;

  @override
  void initState() {
    super.initState();
    initializeSharedPreferences();
  }

  Future<void> initializeSharedPreferences() async {
    sharedPreferences = await SharedPreferences.getInstance();
    setState(() {}); // Trigger rebuild after initialization
  }

  @override
  Widget build(BuildContext context) {
    if (sharedPreferences == null) {
      return Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        automaticallyImplyLeading: false,
        title: Text("Welcome",
          style: CommonStyles.whiteText20BoldW500(),
        ),
        centerTitle: true,
      ),
      body: Container(
        padding: EdgeInsets.symmetric(
          horizontal: 30,

          vertical: 20
        ),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),

          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,

            children: [
            Image.asset("assets/c-logo.jpg"),

              SizedBox(height: 30,),

              Column(
                children: [
                  TextFormField(
                    controller: userTextEditingController,
                    style:CommonStyles.black15(),
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.account_circle),
                      hintText: "User Name",
                      labelText: "User Name",
                      labelStyle: CommonStyles.black15(),
                      hintStyle:  CommonStyles.black13thin(),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  TextFormField(
                    style:CommonStyles.black15(),
                    controller: passwordTextEditingController,
                    obscureText: true,
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.lock),
                      hintText: "Password",
                      labelText: "Password",
                      labelStyle: CommonStyles.black15(),
                      hintStyle:  CommonStyles.black13thin(),
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),

                ],
              ),
              SizedBox(height: 60,),
              Column(
                children: [
                  ElevatedButton(
                      onPressed: () {
                        login();
                      },
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 50),
                        child: Text(
                            "Log In",
                            style:CommonStyles.whiteText18BoldW500()
                        ),
                      ),
                      style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all(Colors.green),
                          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.0),
                                  side: BorderSide(color: Colors.transparent))))),
                  SizedBox(
                    height: 20,
                  ),
                  TextButton(onPressed: (){
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => CreateAccountScreen()));
                  }, child: Text("Create a new Account ?".toUpperCase(),
                    style: CommonStyles.black13(),
                  )),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  void login() {
    if (sharedPreferences == null) {
      return;
    }
    final String? savedEmail = sharedPreferences!.getString('email');
    final String? savedPassword = sharedPreferences!.getString('password');
    if (savedEmail == userTextEditingController.text && savedPassword == passwordTextEditingController.text) {
      Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomePage(
        myIntVal: 0,
      )));
    } else {
      showAlertDialog(context, "Invalid credentials");
    }
  }

  void showAlertDialog(BuildContext context, String message) {
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: TextStyle(color: Colors.green, fontSize: 15),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    AlertDialog alert = AlertDialog(
      title: Text(
        "Alert",
        style: TextStyle(color: Colors.black, fontSize: 15),
      ),
      content: Text(
        message,
        style: TextStyle(color: Colors.black, fontSize: 13),
      ),
      actions: [
        okButton,
      ],
    );

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
