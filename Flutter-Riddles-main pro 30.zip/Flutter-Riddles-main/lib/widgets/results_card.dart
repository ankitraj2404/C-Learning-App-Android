import 'package:flashcards_quiz/common.dart';
import 'package:flashcards_quiz/widgets/dotted_lines.dart';
import 'package:flutter/material.dart';

class ResultsCard extends StatelessWidget {
  const ResultsCard({
    Key? key,
    required this.roundedPercentageScore,
    required this.bgColor3,
  }) : super(key: key);

  final int roundedPercentageScore;
  final Color bgColor3;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.888,
      height: MediaQuery.of(context).size.height * 0.568,
      child: Stack(
        children: [
          Card(
            color: Colors.white,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18.0),
            ),
            elevation: 5,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Expanded(
                    child: Center(
                      child: RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                          children: [
                            for (var ii = 0;
                            ii < "Congratulations!,".length;
                            ii++) ...[
                              TextSpan(
                                text: "Congratulations!,"[ii],
                                style: TextStyle(
                                  fontSize: 12 + ii.toDouble(),
                                  color: Colors.black,
                                ),
                              ),
                            ],
                            //m'adamfo(Twi) - my friend
                            TextSpan(
                              text: " \n You Scored  \n",
                              style: TextStyle(
                                fontSize: 12,
                                color: Colors.black,
                              ),
                            ),
                            TextSpan(
                              text: "$roundedPercentageScore%",
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w500,
                                color: Colors.black,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  CustomPaint(
                    painter: DrawDottedhorizontalline(),
                  ),
                  Expanded(
                    flex: 2,
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.only(top: 25),
                        child: roundedPercentageScore >= 75
                            ? Column(
                          children: [
                            Text(
                              "You have Earned this Trophy",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w400,
                                color: Colors.black,
                              ),
                            ),
                            Image.asset(
                              "assets/bouncy-cup.gif",
                              fit: BoxFit.fill,
                              height:
                              MediaQuery.of(context).size.height *
                                  0.25,
                            ),
                          ],
                        )
                            : Column(
                          children: [
                            Text(
                              "I know You can do better!!",
                              style: TextStyle(
                                fontSize: 16,
                                color: Colors.black,
                              ),
                            ),
                            Image.asset(
                              "assets/sad.png",
                              fit: BoxFit.fill,
                              height:
                              MediaQuery.of(context).size.height *
                                  0.25,
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          Positioned(
            left: -10,
            top: MediaQuery.of(context).size.height * 0.178,
            child: Container(
              height: 25,
              width: 25,
              decoration: BoxDecoration(
                color: bgColor3,
                shape: BoxShape.circle,
              ),
            ),
          ),
          Positioned(
            right: -10,
            top: MediaQuery.of(context).size.height * 0.178,
            child: Container(
              height: 25,
              width: 25,
              decoration: BoxDecoration(
                color: bgColor3,
                shape: BoxShape.circle,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
