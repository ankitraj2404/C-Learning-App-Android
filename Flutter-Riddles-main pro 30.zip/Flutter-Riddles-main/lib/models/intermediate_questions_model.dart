class StateQuestion {
  final int id;
  final String text;
  final List<StateOption> options;
  bool isLocked;
  StateOption? selectedWiidgetOption;
  StateOption? correctAnswer;

  StateQuestion({
    required this.text,
    required this.options,
    this.isLocked = false,
    this.selectedWiidgetOption,
    required this.id,
    required this.correctAnswer,
  });
  StateQuestion copyWith() {
    return StateQuestion(
      id: id,
      text: text,
      options: options
          .map((option) =>
              StateOption(text: option.text, isCorrect: option.isCorrect))
          .toList(),
      isLocked: isLocked,
      selectedWiidgetOption: selectedWiidgetOption,
      correctAnswer: correctAnswer,
    );
  }
}

class StateOption {
  final String text;
  final bool isCorrect;

  const StateOption({
    required this.text,
    required this.isCorrect,
  });
}

final stateQuestionsList = [
  StateQuestion(
    text:
        "What will be the output of the following code ? \n #include <stdio.h>int main() {int x = 5;printf(%d\n, x++);return 0;}",
    options: [
      const StateOption(text: "5", isCorrect: false),
      const StateOption(text: "6", isCorrect: false),
      const StateOption(text: "6", isCorrect: true),
      const StateOption(text: "Compilation Error", isCorrect: false),
    ],
    id: 0,
    correctAnswer: const StateOption(text: "6", isCorrect: true),
  ),
  StateQuestion(
    text:
        "Which of the following is not a valid identifier in C?",
    options: [
      const StateOption(text: "_variable", isCorrect: false),
      const StateOption(text: "1variable", isCorrect: true),
      const StateOption(text: "variable123", isCorrect: false),
      const StateOption(text: "variable_name", isCorrect: false),
    ],
    id: 1,
    correctAnswer: const StateOption(text: "1variable", isCorrect: true),
  ),
  StateQuestion(
    text:
        "Which operator is used to access the value at a memory address in C? ",
    options: [
      const StateOption(text: "&", isCorrect: true),
      const StateOption(text: "*", isCorrect: false),
      const StateOption(text: "#", isCorrect: false),
      const StateOption(text: "()", isCorrect: false),
    ],
    id: 2,
    correctAnswer: const StateOption(text: "*", isCorrect: true),
  ),

  StateQuestion(
    text:
        "What is the value of sizeof(char) in C?",
    options: [
      const StateOption(text: "1", isCorrect: true),
      const StateOption(text: "2", isCorrect: false),
      const StateOption(text: "4", isCorrect: false),
      const StateOption(text: "Depends on the compiler", isCorrect: false),
    ],
    id: 3,
    correctAnswer: const StateOption(text: "1", isCorrect: true),
  ),
  // other 4
  StateQuestion(
    text:
        "What is the output of the following code?",
    options: [
      const StateOption(text: "2", isCorrect: false),
      const StateOption(text: "3", isCorrect: false),
      const StateOption(text: "1", isCorrect: false),
      const StateOption(text: "4", isCorrect: true),
    ],
    id: 4,
    correctAnswer: const StateOption(text: "3", isCorrect: true),
  ),
  StateQuestion(
    text: "What is the purpose of the ‘break’ statement in a switch-case statement in C?",
    options: [
      const StateOption(text: "To exit the entire loop", isCorrect: true),
      const StateOption(text: "To skip the current iteration and move to the next iteration", isCorrect: false),
      const StateOption(text: "To exit the switch-case statement", isCorrect: false),
      const StateOption(text: "To continue to the next case", isCorrect: false),
    ],
    id: 5,
    correctAnswer: const StateOption(text: "To exit the switch-case statement", isCorrect: true),
  ),

  StateQuestion(
    text: "What will be the output of the following code?",
    options: [
      const StateOption(text: "9", isCorrect: false),
      const StateOption(text: "12", isCorrect: false),
      const StateOption(text: "10", isCorrect: false),
      const StateOption(text: "11", isCorrect: true),
    ],
    id: 6,
    correctAnswer: const StateOption(text: "12", isCorrect: true),
  ),
  StateQuestion(
    text:
        "Which of the following is the correct way to declare a pointer to a function in C",
    options: [
      const StateOption(text: "int (*ptr)(int, int);", isCorrect: true),
      const StateOption(text: "int *ptr(int, int);", isCorrect: false),
      const StateOption(text: "(*ptr)(int, int) int;", isCorrect: false),
      const StateOption(text: "ptr(int, int) *int;", isCorrect: false),
    ],
    id: 7,
    correctAnswer: const StateOption(text: "int (*ptr)(int, int);", isCorrect: true),
  ),

  StateQuestion(
    text:
        "What does the ‘fgets()’ function in C do?",
    options: [
      const StateOption(text: "Reads a single character from a file", isCorrect: false),
      const StateOption(text: "Reads a line from a file", isCorrect: false),
      const StateOption(text: "Reads a formatted input from a file", isCorrect: true),
      const StateOption(text: "Reads a word from a file", isCorrect: false),
    ],
    id: 8,
    correctAnswer: const StateOption(text: "Reads a line from a file", isCorrect: true),
  ),

  StateQuestion(
    text:
        "Which of the following is not a valid data type in C?",
    options: [
      const StateOption(text: "float", isCorrect: true),
      const StateOption(text: "char", isCorrect: false),
      const StateOption(text: "string", isCorrect: false),
      const StateOption(text: "double", isCorrect: false),
    ],
    id: 9,
    correctAnswer: const StateOption(text: "string", isCorrect: true),
  ),

  StateQuestion(
    text:
        "What is the output of the following code?",
    options: [
      const StateOption(text: "36", isCorrect: false),
      const StateOption(text: "49", isCorrect: true),
      const StateOption(text: "30", isCorrect: false),
      const StateOption(text: "Compilation Error", isCorrect: false),
    ],
    id: 10,
    correctAnswer: const StateOption(text: "30", isCorrect: true),
  ),

  StateQuestion(
    text:
        "What does the ‘malloc()’ function in C do?",
    options: [
      const StateOption(text: "Allocates memory from the stack", isCorrect: false),
      const StateOption(text: "Deallocates memory from the heap", isCorrect: false),
      const StateOption(text: "Allocates memory from the heap", isCorrect: true),
      const StateOption(text: "Deallocates memory from the stack", isCorrect: false),
    ],
    id: 11,
    correctAnswer: const StateOption(text: "Allocates memory from the heap", isCorrect: true),
  ),


  StateQuestion(
    text:
    "What is the output of the following code?",
    options: [
      const StateOption(text: "1 2 3 4 5", isCorrect: false),
      const StateOption(text: "0 1 2 3 4", isCorrect: false),
      const StateOption(text: "1 2 3 4", isCorrect: true),
      const StateOption(text: "0 1 2 3 4 5", isCorrect: false),
    ],
    id: 12,
    correctAnswer: const StateOption(text: "1 2 3 4 5", isCorrect: true),
  ),

  StateQuestion(
    text:
    "Which of the following is true about ‘typedef’ in C? ",
    options: [
      const StateOption(text: "It's used to define new data types", isCorrect: false),
      const StateOption(text: "It's used to allocate memory", isCorrect: false),
      const StateOption(text: "It's used to declare variables", isCorrect: true),
      const StateOption(text: "It's used to include header files", isCorrect: false),
    ],
    id: 13,
    correctAnswer: const StateOption(text: "It's used to define new data types", isCorrect: true),
  ),

  StateQuestion(
    text:
    "Which of the following functions is used to convert a string to an integer in C?",
    options: [
      const StateOption(text: "atoi()", isCorrect: false),
      const StateOption(text: "itoa()", isCorrect: false),
      const StateOption(text: "strtoi()", isCorrect: true),
      const StateOption(text: "intToStr()", isCorrect: false),
    ],
    id: 14,
    correctAnswer: const StateOption(text: "atoi()", isCorrect: true),
  ),
];
