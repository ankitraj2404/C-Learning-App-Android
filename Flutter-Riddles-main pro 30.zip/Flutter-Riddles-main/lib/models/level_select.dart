import 'package:flashcards_quiz/models/layout_questions_model.dart';
import 'package:flashcards_quiz/models/expert_questions_model.dart';
import 'package:flashcards_quiz/models/beginner_questions_model.dart';
import 'package:flashcards_quiz/models/intermediate_questions_model.dart';
import 'package:flutter/cupertino.dart';

const Color cardColor = Color(0xFF4993FA);

class FlutterLevel {
  final int id;
  final String topicName;
  final IconData topicIcon;
  final Color topicColor;
  final List<dynamic> topicQuestions;

  FlutterLevel({
    required this.id,
    required this.topicColor,
    required this.topicIcon,
    required this.topicName,
    required this.topicQuestions,
  });
}

final List<FlutterLevel> flutterLevelList = [
  FlutterLevel(
    id: 0,
    topicColor: cardColor,
    topicIcon: CupertinoIcons.square_stack_3d_up,
    topicName: "Level 1",
    topicQuestions: widgetQuestionsList,
  ),
  FlutterLevel(
    id: 1,
    topicColor: cardColor,
    topicIcon: CupertinoIcons.arrow_2_circlepath,
    topicName: "Level 2",
    topicQuestions: stateQuestionsList,
  ),
  FlutterLevel(
    id: 2,
    topicColor: cardColor,
    topicIcon: CupertinoIcons.paperplane,
    topicName: "Level 3",
    topicQuestions: navigateQuestionsList,
  ),
];
