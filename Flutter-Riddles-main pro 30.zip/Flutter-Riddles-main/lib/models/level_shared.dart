import 'package:shared_preferences/shared_preferences.dart';

class DataModelClass {
  String roomType = '1';

  Future<void> createStudentData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    roomType = prefs.getString('roomType') ?? '1'; // Default value is '1' if not found
  }

  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('roomType', roomType);
  }
}
