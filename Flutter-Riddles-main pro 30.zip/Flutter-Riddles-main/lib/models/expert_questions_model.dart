class NavigateQuestion {
  final int id;
  final String text;
  final List<NavigationsOption> options;
  bool isLocked;
  NavigationsOption? selectedWiidgetOption;
  NavigationsOption? correctAnswer;

  NavigateQuestion({
    required this.text,
    required this.options,
    this.isLocked = false,
    this.selectedWiidgetOption,
    required this.id,
    required this.correctAnswer,
  });

  NavigateQuestion copyWith() {
    return NavigateQuestion(
      id: id,
      text: text,
      options: options
          .map((option) =>
              NavigationsOption(text: option.text, isCorrect: option.isCorrect))
          .toList(),
      isLocked: isLocked,
      selectedWiidgetOption: selectedWiidgetOption,
      correctAnswer: correctAnswer,
    );
  }
}

class NavigationsOption {
  final String text;
  final bool isCorrect;

  const NavigationsOption({
    required this.text,
    required this.isCorrect,
  });
}

final navigateQuestionsList = [
  NavigateQuestion(
    text:
        "In C, what does the ‘volatile’ keyword signify when applied to a variable?",
    options: [
      const NavigationsOption(text: "It ensures that the variable cannot be modified", isCorrect: false),
      const NavigationsOption(text: "It indicates that the variable's value may change unexpectedly", isCorrect: false),
      const NavigationsOption(text: "It indicates that the variable's value cannot be optimized by the compiler", isCorrect: true),
      const NavigationsOption(text: "It specifies that the variable's value is constant", isCorrect: false),
    ],
    id: 0,
    correctAnswer: const NavigationsOption(text: "It indicates that the variable's value cannot be optimized by the compiler", isCorrect: true),
  ),
  NavigateQuestion(
    text:
        "What is the purpose of the ‘restrict’ keyword in C?",
    options: [
      const NavigationsOption(text: "It restricts the visibility of the variable to the current file", isCorrect: false),
      const NavigationsOption(text: "It specifies that a pointer is the only way to access the object", isCorrect: true),
      const NavigationsOption(
          text: "It restricts the usage of the variable to read-only", isCorrect: false),
      const NavigationsOption(text: "It restricts the type of values that can be assigned to the variable.", isCorrect: false),
    ],
    id: 1,
    correctAnswer:
        const NavigationsOption(text: "Navigator.pop()", isCorrect: true),
  ),
  NavigateQuestion(
    text:
        "I am a widget property that must be passed to navigation methods like Navigator.push() to specify the next screen. What am I?",
    options: [
      const NavigationsOption(text: "context", isCorrect: true),
      const NavigationsOption(text: "Scaffold", isCorrect: false),
      const NavigationsOption(text: "State", isCorrect: false),
      const NavigationsOption(text: "Build", isCorrect: false),
    ],
    id: 2,
    correctAnswer: const NavigationsOption(text: "context", isCorrect: true),
  ),

  NavigateQuestion(
    text:
        "Which of the following functions is used to perform dynamic memory allocation in C?",
    options: [
      const NavigationsOption(text: "calloc()", isCorrect: true),
      const NavigationsOption(text: "malloc()", isCorrect: false),
      const NavigationsOption(text: "realloc()", isCorrect: false),
      const NavigationsOption(text: "free()", isCorrect: false),
    ],
    id: 3,
    correctAnswer:
        const NavigationsOption(text: "malloc()", isCorrect: true),
  ),
  // other 4
  NavigateQuestion(
    text:
        "What is the purpose of the offsetof macro in C?",
    options: [
      const NavigationsOption(text: "It calculates the size of a structure", isCorrect: false),
      const NavigationsOption(text: "It calculates the offset of a member within a structure", isCorrect: false),
      const NavigationsOption(text: "It returns the address of a member within a structure", isCorrect: false),
      const NavigationsOption(text: "It calculates the total number of members in a structure", isCorrect: true),
    ],
    id: 4,
    correctAnswer: const NavigationsOption(
      text: "It calculates the offset of a member within a structure",
      isCorrect: true,
    ),
  ),
  NavigateQuestion(
    text:
        "What does the ‘__func__’ predefined identifier represent in C?",
    options: [
      const NavigationsOption(
          text: "The name of the function in which it appears", isCorrect: true),
      const NavigationsOption(text: "The return type of the function in which it appears", isCorrect: false),
      const NavigationsOption(
          text: "The number of parameters of the function in which it appears", isCorrect: false),
      const NavigationsOption(
          text: "The address of the function in memory", isCorrect: false),
    ],
    id: 5,
    correctAnswer: const NavigationsOption(
        text: "The name of the function in which it appears", isCorrect: true),
  ),

  NavigateQuestion(
    text:
        "Which of the following is a correct way to define a macro function in C?",
    options: [
      const NavigationsOption(text: "#define max(a, b) { (a > b) ? a : b }", isCorrect: false),
      const NavigationsOption(text: "#define max(a, b) ((a > b) ? a : b),", isCorrect: false),
      const NavigationsOption(text: "#define max(a, b) if(a > b) a else b", isCorrect: false),
      const NavigationsOption(text: "#define max(a, b) (a > b) ? a : b", isCorrect: true),
    ],
    id: 6,
    correctAnswer:
        const NavigationsOption(text: "#define max(a, b) ((a > b) ? a : b)", isCorrect: true),
  ),
  NavigateQuestion(
    text:
        "What is the purpose of the volatile qualifier in function prototypes in C?",
    options: [
      const NavigationsOption(text: "It ensures that the function cannot be modified", isCorrect: true),
      const NavigationsOption(text: "It indicates that the function's return value may change unexpectedly", isCorrect: false),
      const NavigationsOption(text: "It specifies that the function should not be optimized by the compiler", isCorrect: false),
      const NavigationsOption(text: "It makes the function thread-safe", isCorrect: false),
    ],
    id: 7,
    correctAnswer: const NavigationsOption(text: "It specifies that the function should not be optimized by the compiler", isCorrect: true),
  ),

  NavigateQuestion(
    text:
        "What is the difference between malloc() and calloc() in C?",
    options: [
      const NavigationsOption(text: "calloc() allocates memory for arrays", isCorrect: false),
      const NavigationsOption(text: "malloc() initializes memory to zero", isCorrect: false),
      const NavigationsOption(text: "calloc() allocates contiguous memory blocks", isCorrect: true),
      const NavigationsOption(text: "malloc() doesn't initialize memory", isCorrect: false),
    ],
    id: 8,
    correctAnswer:
        const NavigationsOption(text: "malloc() doesn't initialize memory", isCorrect: true),
  ),

  NavigateQuestion(
    text:
        "Which of the following is true about the union data type in C?",
    options: [
      const NavigationsOption(text: "It allows the storage of multiple data types in a single variable", isCorrect: false),
      const NavigationsOption(text: "It allocates memory for all its members simultaneously", isCorrect: false),
      const NavigationsOption(text: "It always allocates memory equal to the size of the largest member", isCorrect: true),
      const NavigationsOption(text: "It cannot contain pointers as members", isCorrect: false),
    ],
    id: 9,
    correctAnswer:
        const NavigationsOption(text: "It allows the storage of multiple data types in a single variable", isCorrect: true),
  ),

  NavigateQuestion(
    text:
        "What is the purpose of the __FILE__ predefined identifier in C?",
    options: [
      const NavigationsOption(text: "It returns the name of the current function", isCorrect: false),
      const NavigationsOption(text: "It returns the name of the current source file", isCorrect: false),
      const NavigationsOption(text: "It returns the line number of the current code", isCorrect: true),
      const NavigationsOption(text: "It returns the name of the header file being included", isCorrect: false),
    ],
    id: 10,
    correctAnswer:
        const NavigationsOption(text: "It returns the name of the current source file", isCorrect: true),
  ),

  NavigateQuestion(
    text:
        "What is function pointer in C?",
    options: [
      const NavigationsOption(text: "A pointer that stores the address of a function", isCorrect: false),
      const NavigationsOption(text: "A pointer that can only point to function variables", isCorrect: false),
      const NavigationsOption(text: "A pointer that can only be used inside a function", isCorrect: true),
      const NavigationsOption(text: "A pointer that can only be used to access global functions", isCorrect: false),
    ],
    id: 11,
    correctAnswer:
        const NavigationsOption(text: "A pointer that stores the address of a function", isCorrect: true),
  ),

  NavigateQuestion(
    text:
        "Which statement is correct regarding the const qualifier in C?",
    options: [
      const NavigationsOption(text: "It can only be applied to global variables", isCorrect: false),
      const NavigationsOption(text: "It makes a variable constant", isCorrect: false),
      const NavigationsOption(text: "It can only be applied to pointers", isCorrect: true),
      const NavigationsOption(text: "It allows the variable's value to be modified", isCorrect: false),
    ],
    id: 12,
    correctAnswer:
        const NavigationsOption(text: "It makes a variable constant", isCorrect: true),
  ),

  NavigateQuestion(
    text:
        "What is the purpose of the memset() function in C?",
    options: [
      const NavigationsOption(text: "Allocates memory for a variable", isCorrect: false),
      const NavigationsOption(text: "Frees memory allocated by malloc()", isCorrect: false),
      const NavigationsOption(text: "Initializes a block of memory to a particular value", isCorrect: true),
      const NavigationsOption(text: "Copies memory from one location to another", isCorrect: false),
    ],
    id: 13,
    correctAnswer:
        const NavigationsOption(text: "Initializes a block of memory to a particular value", isCorrect: true),
  ),

  NavigateQuestion(
    text:
        "What does the volatile keyword signify when applied to a function in C?",
    options: [
      const NavigationsOption(text: "It ensures that the function cannot be modified", isCorrect: false),
      const NavigationsOption(text: "It indicates that the function's return value may change unexpectedly", isCorrect: false),
      const NavigationsOption(text: "It specifies that the function should not be optimized by the compiler", isCorrect: true),
      const NavigationsOption(text: "It makes the function thread-safe", isCorrect: false),
    ],
    id: 14,
    correctAnswer:
        const NavigationsOption(text: "It specifies that the function should not be optimized by the compiler", isCorrect: true),
  ),

  NavigateQuestion(
    text:
        "What is the purpose of the restrict qualifier in C?",
    options: [
      const NavigationsOption(text: "It specifies that a pointer is the only way to access the object", isCorrect: false),
      const NavigationsOption(text: "It restricts the visibility of the variable to the current file", isCorrect: false),
      const NavigationsOption(text: "It specifies that the function should not be optimized by the compiler", isCorrect: true),
      const NavigationsOption(text: "It makes the function thread-safe", isCorrect: false),
    ],
    id: 15,
    correctAnswer:
        const NavigationsOption(text: "It specifies that a pointer is the only way to access the object", isCorrect: true),
  ),
];
