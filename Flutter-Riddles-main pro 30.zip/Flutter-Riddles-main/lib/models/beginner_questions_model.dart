class WidgetQuestion {
  final int id;
  final String text;
  final List<WiidgetOption> options;
  bool isLocked;
  WiidgetOption? selectedWiidgetOption;
  WiidgetOption correctAnswer;

  WidgetQuestion({
    required this.text,
    required this.options,
    this.isLocked = false,
    this.selectedWiidgetOption,
    required this.id,
    required this.correctAnswer,
  });

  WidgetQuestion copyWith() {
    return WidgetQuestion(
      id: id,
      text: text,
      options: options
          .map((option) =>
              WiidgetOption(text: option.text, isCorrect: option.isCorrect))
          .toList(),
      isLocked: isLocked,
      selectedWiidgetOption: selectedWiidgetOption,
      correctAnswer: correctAnswer,
    );
  }
}

class WiidgetOption {
  final String? text;
  final bool? isCorrect;

  const WiidgetOption({
    this.text,
    this.isCorrect,
  });
}

final widgetQuestionsList = [
  WidgetQuestion(
    text: "What is the correct way to declare a variable in C?",
    options: [
      const WiidgetOption(text: "variable x", isCorrect: true),
      const WiidgetOption(text: "x = int", isCorrect: false),
      const WiidgetOption(text: "int x", isCorrect: false),
      const WiidgetOption(text: "int variable x", isCorrect: false),
    ],
    id: 0,
    correctAnswer: const WiidgetOption(text: "int x", isCorrect: true),
  ),
  WidgetQuestion(
      text: "What does the printf function do in C?",
      options: [
        const WiidgetOption(
            text: "Reads input from the user ", isCorrect: false),
        const WiidgetOption(
            text: "Prints output to the console", isCorrect: true),
        const WiidgetOption(
            text: "Performs mathematical calculations ", isCorrect: false),
        const WiidgetOption(text: "Declares variables", isCorrect: false),
      ],
      id: 1,
      correctAnswer: const WiidgetOption(
          text: "Prints output to the console", isCorrect: true)),
  WidgetQuestion(
      text:
          "Which operator is used to access the value at a memory address in C? ",
      options: [
        const WiidgetOption(text: "&", isCorrect: false),
        const WiidgetOption(text: "*", isCorrect: false),
        const WiidgetOption(text: "#", isCorrect: false),
        const WiidgetOption(text: "(", isCorrect: true),
      ],
      id: 2,
      correctAnswer: const WiidgetOption(text: "*", isCorrect: true)),
  WidgetQuestion(
      text: "4.	What is the result of the expression: 10 % 3 in C? ",
      options: [
        const WiidgetOption(text: "0", isCorrect: false),
        const WiidgetOption(text: "1", isCorrect: false),
        const WiidgetOption(text: "2", isCorrect: true),
        const WiidgetOption(text: "3", isCorrect: false),
      ],
      id: 3,
      correctAnswer: const WiidgetOption(text: "1", isCorrect: true)),
  WidgetQuestion(
      text: "Which statement is used to terminate a loop in C?",
      options: [
        const WiidgetOption(text: "exit", isCorrect: false),
        const WiidgetOption(text: "quit", isCorrect: false),
        const WiidgetOption(text: "break", isCorrect: false),
        const WiidgetOption(text: "stop", isCorrect: true),
      ],
      id: 4,
      correctAnswer: const WiidgetOption(text: "break", isCorrect: true)),
  WidgetQuestion(
      text: "What is the purpose of the sizeof operator in C? ",
      options: [
        const WiidgetOption(
            text: "To find the size of a variable", isCorrect: true),
        const WiidgetOption(text: "To perform division", isCorrect: false),
        const WiidgetOption(text: "To compare two variables", isCorrect: false),
        const WiidgetOption(text: "To declare a variable", isCorrect: false),
      ],
      id: 5,
      correctAnswer: const WiidgetOption(
          text: "To find the size of a variable", isCorrect: true)),
  WidgetQuestion(
      text: "Which keyword is used to define a constant in C",
      options: [
        const WiidgetOption(text: "define", isCorrect: true),
        const WiidgetOption(text: "constant", isCorrect: false),
        const WiidgetOption(text: "const", isCorrect: false),
        const WiidgetOption(text: "final", isCorrect: false),
      ],
      id: 6,
      correctAnswer: const WiidgetOption(text: "const", isCorrect: true)),
  WidgetQuestion(
      text: "What is the correct syntax for a single-line comment in C ?",
      options: [
        const WiidgetOption(text: "// This is a comment", isCorrect: true),
        const WiidgetOption(text: "# This is a comment", isCorrect: false),
        const WiidgetOption(text: "/* This is a comment */ ", isCorrect: false),
        const WiidgetOption(text: "' This is a comment", isCorrect: false),
      ],
      id: 7,
      correctAnswer:
          const WiidgetOption(text: "// This is a comment \nint x = 5; int y = x++; printf(%d, y);", isCorrect: true)),
  WidgetQuestion(
      text:
          "What is the output of the following code snippet:",
      options: [
        const WiidgetOption(text: "4", isCorrect: true),
        const WiidgetOption(text: "5", isCorrect: false),
        const WiidgetOption(text: "6", isCorrect: false),
        const WiidgetOption(text: "Compilation Error", isCorrect: false),
      ],
      id: 8,
      correctAnswer: const WiidgetOption(text: "5", isCorrect: true)),
  WidgetQuestion(
      text:
          "Which of the following is not a valid data type in C? ",
      options: [
        const WiidgetOption(text: "float", isCorrect: true),
        const WiidgetOption(text: "char", isCorrect: false),
        const WiidgetOption(text: "string", isCorrect: false),
        const WiidgetOption(text: "double", isCorrect: false),
      ],
      id: 9,
      correctAnswer: const WiidgetOption(text: "string", isCorrect: true)),
  WidgetQuestion(
      text:
          "What does the scanf function do in C?",
      options: [
        const WiidgetOption(text: "Prints output to the console", isCorrect: false),
        const WiidgetOption(text: "Reads input from the user", isCorrect: false),
        const WiidgetOption(text: "Declares variables", isCorrect: true),
        const WiidgetOption(text: "Performs mathematical calculations", isCorrect: false),
      ],
      id: 10,
      correctAnswer: const WiidgetOption(
          text: "Reads input from the user", isCorrect: true)),
  WidgetQuestion(
      text:
          "What does the strcmp function do in C? ",
      options: [
        const WiidgetOption(text: "Compares two strings", isCorrect: false),
        const WiidgetOption(text: "Copies one string to another", isCorrect: true),
        const WiidgetOption(text: "Concatenates two strings", isCorrect: false),
        const WiidgetOption(text: "Searches for a substring in a string", isCorrect: false),
      ],
      id: 11,
      correctAnswer: const WiidgetOption(text: "Compares two strings", isCorrect: true)),
  WidgetQuestion(
      text:
          "Which operator is used for logical AND in C?",
      options: [
        const WiidgetOption(text: "&&", isCorrect: false),
        const WiidgetOption(text: "||", isCorrect: true),
        const WiidgetOption(text: "&", isCorrect: false),
        const WiidgetOption(text: "|", isCorrect: false),
      ],
      id: 12,
      correctAnswer: const WiidgetOption(text: "&&", isCorrect: true)),
  WidgetQuestion(
      text:
          "What is the correct syntax for a switch statement in C?",
      options: [
        const WiidgetOption(text: "switch (condition) { case 1: break; default: break; }", isCorrect: true),
        const WiidgetOption(text: "switch { case 1: break; default: break; }", isCorrect: false),
        const WiidgetOption(text: "switch (condition) [ case 1: break; default: break; ]", isCorrect: false),
        const WiidgetOption(text: "switch (condition) { case 1; break; default; break; }", isCorrect: false),
      ],
      id: 13,
      correctAnswer: const WiidgetOption(text: "switch (condition) { case 1: break; default: break; }", isCorrect: true)),
  WidgetQuestion(
    text:
        "What is the output of the following code snippet: \n int i = 0;\nwhile (i < 5) {\nprintf(%, i);i += 2;\n}",
    options: [
      const WiidgetOption(text: "0 1 2 3 4 ", isCorrect: false),
      const WiidgetOption(text: "0 2 4", isCorrect: true),
      const WiidgetOption(text: "2 4", isCorrect: false),
      const WiidgetOption(text: "Compilation Error", isCorrect: false),
    ],
    id: 14,
    correctAnswer:
        const WiidgetOption(text: "0 2 4", isCorrect: true),
  ),
];
