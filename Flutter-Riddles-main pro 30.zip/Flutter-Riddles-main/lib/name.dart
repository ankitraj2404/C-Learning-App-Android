import 'package:flashcards_quiz/common.dart';
import 'package:flashcards_quiz/views/profile.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';




class NameList extends StatefulWidget {
  const NameList({super.key});

  @override
  State<NameList> createState() => _NameListState();
}

class _NameListState extends State<NameList> {

  List<String> name = [
    'Kirthika',
    'Prasath',
    'Kavin',
    'Pradeep',
    'Ram',
    'Ganesh',
    'Sarath',
    'David',
    'Karthika',
    'Kokila'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        backgroundColor: Colors.green,

        title: Text("",
          style: CommonStyles.whiteText20BoldW500(),
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle),
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(builder: (context)=> ProfileScreen()));
            },
          ),
          IconButton(
            icon: Icon(Icons.account_balance),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ],

      ),

      body: Container(
        padding: EdgeInsets.all(30),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            children: [


           FutureBuilder<int>(
          future: _getRoundedPercentageScore(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            } else {
              int roundedPercentageScore = snapshot.data ?? 0;
              return  Padding(
                padding: const EdgeInsets.symmetric(vertical: 20.0),
                child: Card(
                  elevation: 20,
                  shadowColor: Colors.white,
                  color: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(
                          color: Colors.green
                      )
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 20.0,
                        horizontal: 20
                    ),
                    child: Row(
                      children: [

IconButton(onPressed: (){}, icon: Icon(Icons.supervised_user_circle)),
                        SizedBox(
                          width: 200,
                          child: Text("You ",
                            style: CommonStyles.black14(),
                          ),
                        ),

                        SizedBox(
                          width: 15,
                        ),

                        Text("$roundedPercentageScore%",
                          style: CommonStyles.black13(),
                        )
                      ],
                    ),
                  ),
                ),
              );



            }
          },
        ),

              SizedBox(
                height: 30,
              ),

              ListView.builder(
                  itemCount: 10,
                  shrinkWrap: true,
                  primary: false,

                  itemBuilder: (context,index){
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20.0),
                  child: Card(
                    elevation: 20,
                    shadowColor: Colors.white,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(
                        color: Colors.green
                      )
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 20.0,
                      horizontal: 20
                      ),
                      child: Row(
                        children: [
                          Text((index+1).toString() as String,
                          style: CommonStyles.black14(),
                          ),

                          SizedBox(
                            width: 25,
                          ),

                          SizedBox(
                            width: 200,
                            child: Text(name[index],
                            style: CommonStyles.black14(),
                            ),
                          ),

                          SizedBox(
                            width: 15,
                          ),
                          
                          Text("210",
                          style: CommonStyles.black13(),
                          )
                        ],
                      ),
                    ),
                  ),
                );
              })
            ],
          ),
        ),
      ),

    );
  }



  Future<int> _getRoundedPercentageScore() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getInt('roundedPercentageScore') ?? 0;
  }
}
