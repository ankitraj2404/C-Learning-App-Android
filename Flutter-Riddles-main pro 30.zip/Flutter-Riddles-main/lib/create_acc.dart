
import 'package:flashcards_quiz/common.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';


class CreateAccountScreen extends StatefulWidget {
  const CreateAccountScreen({Key? key}) : super(key: key);

  @override
  State<CreateAccountScreen> createState() => _CreateAccountScreenState();
}

class _CreateAccountScreenState extends State<CreateAccountScreen> {
  final TextEditingController userTextEditingController = TextEditingController();
  final TextEditingController emailTextEditingController = TextEditingController();
  final TextEditingController passwordTextEditingController = TextEditingController();
  final TextEditingController confirmpasswordTextEditingController = TextEditingController();

  SharedPreferences? sharedPreferences;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((prefs) {
      setState(() {
        sharedPreferences = prefs;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        automaticallyImplyLeading: false,
        title: Text(
          "Welcome",
          style: CommonStyles.whiteText15BoldW500(),
        ),
        centerTitle: true,
      ),
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 30, vertical: 20),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.supervised_user_circle_sharp,
                    color: Colors.blue[900],
                    size: 45,
                  ),
                  SizedBox(width: 30),
                  Text(
                    "Sign Up",
                    style: CommonStyles.blue20900(),
                  ),
                ],
              ),
              SizedBox(height: 80),
              Column(
                children: [
                  TextFormField(
                    style:CommonStyles.black13(),
                    controller: userTextEditingController,
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.account_circle),
                      hintText: "Create User Name",
                      labelText: "Create User Name",
                      hintStyle:  CommonStyles.black13(),
                      labelStyle:  CommonStyles.black13(),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                  SizedBox(height: 30),
                  TextFormField(
                    style:CommonStyles.black13(),
                    controller: emailTextEditingController,
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.email_outlined),
                      hintText: "E-Mail Id",
                      labelText: "E-Mail Id",
                      hintStyle:  CommonStyles.black13(),
                      labelStyle:  CommonStyles.black13(),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                  SizedBox(height: 30),
                  TextFormField(
                    style:CommonStyles.black13(),
                    controller: passwordTextEditingController,
                    obscureText: true,
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.lock),
                      hintText: "Create Password",
                      labelText: "Create Password",
                      hintStyle:  CommonStyles.black13(),
                      labelStyle:  CommonStyles.black13(),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                  SizedBox(height: 15),
                  TextFormField(
                    controller: confirmpasswordTextEditingController,
                    obscureText: true,
                    style:CommonStyles.black13(),
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.lock),
                      hintText: "Confirm Password",
                      labelText: "Confirm Password",
                      hintStyle:  CommonStyles.black13(),
                      labelStyle:  CommonStyles.black13(),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
                    ),
                  ),
                  SizedBox(height: 15),
                ],
              ),
              SizedBox(height: 60),
              ElevatedButton(
                onPressed: () {
                  saveUserData();
                  Navigator.of(context).pop();
                },
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 50),
                  child: Text(
                    "SIGN UP",
                    style: CommonStyles.whiteText20BoldW500(),
                  ),
                ),
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all(Colors.green),
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.0),
                      side: BorderSide(color: Colors.transparent),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void saveUserData() {
    sharedPreferences!.setString('username', userTextEditingController.text);
    sharedPreferences!.setString('email', emailTextEditingController.text);
    sharedPreferences!.setString('password', passwordTextEditingController.text);
  }
}