import 'package:flashcards_quiz/common.dart';
import 'package:flashcards_quiz/models/level_shared.dart';
import 'package:flashcards_quiz/views/flashcard_screen.dart';
import 'package:flashcards_quiz/views/home_screen.dart';
import 'package:flashcards_quiz/widgets/results_card.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ResultsScreen extends StatefulWidget {
  const ResultsScreen(
      {super.key,
      required this.score,
      required this.levelNo,
      required this.totalQuestions,
      required this.whichTopic,
        required this.topicName,
        required this.typeOfTopic
      });
  final int score;
  final int levelNo;
  final int totalQuestions;
  final String topicName;
  final String whichTopic;
  final List<dynamic> typeOfTopic;

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {

  DataModelClass _model = DataModelClass();


  Future<void> _initData() async {
    await _model.createStudentData(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }
  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {

    });
    // Load data when initializing the state
  }
  @override
  Widget build(BuildContext context) {
    const Color bgColor3 = Colors.green;
    print(widget.score);
    print(widget.totalQuestions);
    final double percentageScore = (widget.score / widget.totalQuestions) * 100;
    final int roundedPercentageScore = percentageScore.round();
    const Color cardColor = Color(0xFF4993FA);
    return WillPopScope(
      onWillPop: () {
        Navigator.popUntil(context, (route) => route.isFirst);
        return Future.value(false);
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          }, icon: Icon(Icons.arrow_back_ios,
          color: Colors.white,
          )),
          backgroundColor: Colors.green,
          automaticallyImplyLeading: false,
          title: Text(
            "Result ",
            style: CommonStyles.whiteText20BoldW500(),
          ),
          centerTitle: true,
        ),

        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: "Results On Your ",
                      style:
                         CommonStyles.blackText17BoldW500()
                    ),
                    for (var i = 0; i < "Riddles!!!".length; i++) ...[
                      TextSpan(
                        text: "Attempt !!!"[i],
                        style:
                            CommonStyles.black15()
                      ),
                    ]
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(25.0),
                child: Text(
                  widget.whichTopic.toUpperCase(),
                  style: CommonStyles.green15(),
                ),
              ),

              Padding(
                padding: const EdgeInsets.all(25.0),
                child: Text(
                  "Level  -  ${widget.levelNo+1}".toString().toUpperCase(),
                  style: CommonStyles.redText20BoldW500(),
                ),
              ),

              ResultsCard(
                  roundedPercentageScore: roundedPercentageScore,
                  bgColor3: Colors.green),
              const SizedBox(
                height: 25,
              ),
              ElevatedButton(
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all(cardColor),
                  fixedSize: MaterialStateProperty.all(
                    Size(MediaQuery.sizeOf(context).width * 0.80, 40),
                  ),
                  elevation: MaterialStateProperty.all(4),
                ),
                onPressed: () async{
                  await _model.roomType == "1"+1.toString();

                  if( widget.whichTopic== 'Beginner' &&widget.levelNo+1 == 3){
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomePage(
                      myIntVal: 1,
                    )));
                  }
                  else if( widget.whichTopic== 'Intermediate' &&widget.levelNo+1 == 3){
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomePage(
                      myIntVal: 2,
                    )));
                  }
                  else if(widget.levelNo+1 >=3) {
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomePage(
                    myIntVal: 1,
                    )));



                  }
                  else{
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => NewCard(
                          typeOfTopic: widget.typeOfTopic,
                          topicName: widget.topicName,
                        ),
                      ),
                    );
                  }
                },
                child:  Text(
                  "Take another test",
                  style: CommonStyles.whiteText20BoldW500()
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
