import 'package:flashcards_quiz/common.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';


class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {

  TextEditingController _nameController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _pointsController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadProfileData();
  }

  Future<void> _loadProfileData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _nameController.text = prefs.getString('userName') ?? '';
      _emailController.text = prefs.getString('email') ?? '';
      _pointsController.text = prefs.getInt('points').toString() ?? '';
    });
  }

  Future<void> _saveProfileData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setString('userName', _nameController.text);
    prefs.setString('email', _emailController.text);
    prefs.setInt('points', int.tryParse(_pointsController.text) ?? 0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        backgroundColor: Colors.green,

        title: Text("Profile",
          style: CommonStyles.whiteText20BoldW500(),
        ),
        centerTitle: true,
      ),

      body: Container(
        padding: EdgeInsets.all(30),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            children: [

              SizedBox(height: 25.0),

              TextFormField(
                controller: _nameController,
                style: CommonStyles.black15(),
                decoration: InputDecoration(
                  labelText: 'Name',
                  hintText: 'Enter your name',
                  border: UnderlineInputBorder(),
                ),
              ),
              SizedBox(height: 25.0),
              TextFormField(
                controller: _emailController,
                style: CommonStyles.black15(),

                decoration: InputDecoration(
                  labelText: 'Email',
                  hintText: 'Enter your email',
                  border: UnderlineInputBorder(),
                ),
              ),
              SizedBox(height: 25.0),
              TextFormField(
                controller: _pointsController,
                style: CommonStyles.black15(),

                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Points Gained',
                  hintText: 'Enter your points gained',
                  border: UnderlineInputBorder(),
                ),
              ),
              SizedBox(height: 50.0),


              ElevatedButton(
                  onPressed: () {
                    _saveProfileData();
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 10, horizontal: 50),
                    child: Text(
                        "Save",
                        style:CommonStyles.whiteText18BoldW500()
                    ),
                  ),
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.green),
                      shape:
                      MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              side: BorderSide(color: Colors.transparent))))),
            ],
          ),
        ),
      ),
    );
  }
}
