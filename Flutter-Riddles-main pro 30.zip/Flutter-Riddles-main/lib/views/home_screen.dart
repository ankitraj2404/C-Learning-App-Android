import 'package:flashcards_quiz/common.dart';
import 'package:flashcards_quiz/login_screen.dart';
import 'package:flashcards_quiz/models/level_shared.dart';
import 'package:flashcards_quiz/models/level_topics_model.dart';
import 'package:flashcards_quiz/views/flashcard_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomePage extends StatefulWidget {
  final int myIntVal; // Define myIntVal as a property of the widget

  // Constructor with named parameter myIntVal
  HomePage({Key? key, required this.myIntVal}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  DataModelClass _model = DataModelClass();

  Future<void> _initData() async {
    await _model.createStudentData(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }

  @override
  void initState() {
    super.initState();
    _initData();
  }

  @override
  Widget build(BuildContext context) {
    // You can access myIntVal using widget.myIntVal
    int myIntValue = widget.myIntVal; // Example integer value

    const Color bgColor = Color(0xFF4993FA);
    const Color bgColor3 = Color(0xFF5170FD);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        automaticallyImplyLeading: false,
        title: Text(
          "Competency Level",
          style: CommonStyles.whiteText20BoldW500(),
        ),
        centerTitle: true,
        actions: [
          IconButton(onPressed: (){
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => LoginScreen()),
            );
          }, icon: Icon(Icons.logout,
          color: Colors.white,
          ))
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 0, left: 15, right: 15),
          child: ListView(
            physics: const BouncingScrollPhysics(),
            children: [
              Container(
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.24),
                      blurRadius: 20.0,
                      offset: const Offset(0.0, 10.0),
                      spreadRadius: -10,
                      blurStyle: BlurStyle.outer,
                    )
                  ],
                ),
                child: Image.asset("assets/c-logo.jpg"),
              ),
              const SizedBox(
                height: 10,
              ),
              const SizedBox(
                height: 50,
              ),
              ListView.builder(
                shrinkWrap: true,
                physics: const BouncingScrollPhysics(),
                itemCount: flutterTopicsList.length,
                padding: EdgeInsets.only(bottom: 30),
                itemBuilder: (context, index) {
                  final topicsData = flutterTopicsList[index];
                  return GestureDetector(
                    onTap: () {
                      if (widget.myIntVal == topicsData.id)
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => NewCard(
                              typeOfTopic: topicsData.topicQuestions,
                              topicName: topicsData.topicName,
                            ),
                          ),
                        );
                      print(topicsData.topicName);
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 15.0),
                      child: Card(
                        color: Colors.white,
                        elevation: 30,
                        shadowColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                            side: BorderSide(color: Colors.green)),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 30.0),
                          child: Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(topicsData.topicName,
                                    textAlign: TextAlign.center,
                                    style: CommonStyles.black15())
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
